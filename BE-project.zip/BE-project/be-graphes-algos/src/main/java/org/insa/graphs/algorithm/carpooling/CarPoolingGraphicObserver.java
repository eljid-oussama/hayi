package org.insa.graphs.algorithm.carpooling;

public class CarPoolingGraphicObserver implements CarPoolingObserver {

}
