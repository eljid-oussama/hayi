package org.insa.graphs.algorithm.packageswitch;

public interface PackageSwitchObserver {

}
