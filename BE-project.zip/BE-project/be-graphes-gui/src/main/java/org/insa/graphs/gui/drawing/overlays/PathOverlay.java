package org.insa.graphs.gui.drawing.overlays;

public interface PathOverlay extends Overlay {

}
