package org.insa.graphs.algorithm.carpooling;

import org.insa.graphs.algorithm.AbstractSolution;

public class CarPoolingSolution extends AbstractSolution {

    protected CarPoolingSolution(CarPoolingData data, Status status) {
        super(data, status);
    }

}
