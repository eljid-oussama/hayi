package org.insa.graphs.algorithm.packageswitch;

public class PackageSwitchTextObserver implements PackageSwitchObserver {

}
